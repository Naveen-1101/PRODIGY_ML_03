# PRODIGY_ML_03
Implement a support vector machine (SVM) to classify images of cats and dogs from the Kaggle dataset.


Dataset link : https://www.kaggle.com/c/dogs-vs-cats/data

Dataset formate

database_mini /
      ../cat
      ../dog
